varGlob = 10
termPar = 0
fib = 1
aux=0
for i in range(varGlob):
    print(fib)
    aux, fib = fib, fib+aux
        