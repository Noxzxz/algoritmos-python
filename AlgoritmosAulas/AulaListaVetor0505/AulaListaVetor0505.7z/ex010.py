decimal = int(input("Insira um valor de base decimal: "))
num1 = decimal%2
num2 = decimal//2
print(num1, num2)