def soma(a,b):
    return (a+b)

def mult(a,b):
    return (a*b)

def subtr(a,b):
    return(a-b)

def divis(a,b):
    return(a/b)