a = int(input('Insira o valor da base: '))
b = int(input('Insira o valor da altura: '))

c = a*b #area
p = 2*a + 2*b #perimetro

print('A area do retangulo é {}, o perimetro é {}'.format(c,p))
