a = int(input('Insira a temperatura em celsius: '))

f= (a*9)/5 + 32

print('A temperatura em celsius é {}ºc, fareheit {}ºf'.format(a,f))