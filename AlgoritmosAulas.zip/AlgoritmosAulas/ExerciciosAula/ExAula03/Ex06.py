x = int(input('Insira um valor para a equação:'))

a = (x-(1/2)) ** (1/3)
a= a**(1/2)

print('O valor da equação é {:.2f}'.format(a))