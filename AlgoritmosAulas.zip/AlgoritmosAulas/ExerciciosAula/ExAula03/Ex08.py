string = input('Insira um numero de 3 digitos: ')
a = string[1]

print('O numero da dezena é {}'.format(a))