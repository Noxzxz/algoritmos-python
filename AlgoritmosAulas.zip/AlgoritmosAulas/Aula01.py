a = int(input('Digite a altura do triangulo'))
b = int(input('Digite a base do triangulo'))

c = (a*b)/2

print('A área do triangulo é {}'.format(c))