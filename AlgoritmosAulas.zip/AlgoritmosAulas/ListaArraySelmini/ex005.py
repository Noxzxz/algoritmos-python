n = int(input("Insira um numero: "))

for i in range(1,n+1):
    for t in range(1,i+1):
        print("%", end="")
    print("")