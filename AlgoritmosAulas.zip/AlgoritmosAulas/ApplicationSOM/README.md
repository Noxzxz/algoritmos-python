# ApplicationSOM
library for applying a SOM (self-organizing-map) model in a simplified and effective way, inspired by the Kohonen map postulated in 1982
