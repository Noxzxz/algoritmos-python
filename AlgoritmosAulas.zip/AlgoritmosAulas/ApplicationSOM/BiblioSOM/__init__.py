from InputNeuron import adicao
