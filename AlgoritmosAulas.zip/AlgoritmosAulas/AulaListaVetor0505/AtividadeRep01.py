lin = int(input("Insira um valor: "))

for i in range (1, lin+2):
    for a in range(1,i):
        print(a,"", end='')
    print("")