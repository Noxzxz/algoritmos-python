x = [2,5,7,6,8]

print(x)

for i in (x):
    print(i, end=" ")

print('')
lista = []

for i in range(5):
    lista.append(int(input("insira o valor {}°: ".format(i+1))))

print(lista)

